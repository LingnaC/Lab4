package com.biblioteca.inter;

public interface ProfileInterface {

    void changePassword(String newPassword);
}
