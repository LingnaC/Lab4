package com.biblioteca.inter;

public interface ArchiveInterface {

    void export();

    void read();
}
