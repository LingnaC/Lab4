package com.biblioteca.inter;

public interface LoadInterface {
    void showlistResources();

    void returningDays();
    
}